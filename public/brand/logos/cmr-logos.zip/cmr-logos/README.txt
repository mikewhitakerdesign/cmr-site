Chicago Mountain Runners logo files
====================================

Badge (primary identity)       cmr-badge-black.svg / .png, cmr-badge-white.svg / .png
Wordmark (the full name)       cmr-wordmark-black.svg / .png, cmr-wordmark-white.svg / .png

SVG is the master: use it for anything printed, cut, stitched or enlarged.
PNG (3000 px wide, transparent) is for documents and screens.
Black for white and light grounds; white for black and dark grounds.
The letters in the badge are cut out: whatever is behind the badge shows through them.

Use the files as supplied: no stretching, recoloring, outlines, effects or retyping.
Keep the TM. Give the badge clear space equal to the height of its letters.
Screen: the badge is never shown narrower than 96 px.
Print, embroidery and other materials: agree the smallest size with the vendor and proof it.

The complete standards: https://chicagomountainrunners.com/brand/marks
